import { useState, useEffect, ReactNode } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useMotionValueEvent } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import {
  FiInstagram, FiTwitter, FiYoutube, FiMail, FiPhone, FiMapPin,
  FiArrowDown, FiPlay, FiMenu, FiX, FiChevronRight,
  FiCamera, FiFilm, FiVideo, FiMonitor, FiAperture, FiEdit3
} from 'react-icons/fi';
import { FaTiktok } from 'react-icons/fa6';

// ==================== TYPES ====================
interface Project {
  id: number;
  title: string;
  category: string;
  image: string;
  description: string;
  tags: string[];
}

interface Skill {
  name: string;
  level: number;
  icon: ReactNode;
}

interface Service {
  title: string;
  description: string;
  icon: ReactNode;
  features: string[];
}

interface Stat {
  value: string;
  label: string;
}

// ==================== DATA ====================
const projects: Project[] = [
  {
    id: 1,
    title: "Shine Gospel Africa",
    category: "Événement Gospel",
    image: "/images/intro.jpeg",
    description: "Couverture audiovisuelle complète d'événements gospel et productions médiatiques chrétiennes",
    tags: ["Captation", "Montage", "Réseaux Sociaux"]
  },
  {
    id: 2,
    title: "Concert Christian Mukuna",
    category: "Concert Live",
    image: "/images/red2.jpg",
    description: "Couverture vidéo complète du concert avec prises de vues live et highlights événementiels",
    tags: ["Live", "Highlights", "Aftermovie"]
  },
  {
    id: 3,
    title: "Concert Déborah Lukalu",
    category: "Production Audiovisuelle",
    image: "/images/bad2.jpg",
    description: "Production de contenus audiovisuels événementiels incluant vidéos teaser et captation scénique",
    tags: ["Teaser", "Captation", "Aftermovie"]
  },
  {
    id: 4,
    title: "14ème Congrès AUA",
    category: "Événement Institutionnel",
    image: "/images/projet3.jpeg",
    description: "Réalisation de contenus vidéo institutionnels et événementiels pour le congrès",
    tags: ["Institutionnel", "Interviews", "Communication"]
  },
  {
    id: 5,
    title: "Expo Béton 10ème Édition",
    category: "Reportage Architectural",
    image: "/images/projet4.jpeg",
    description: "Couverture médiatique avec reportage vidéo et mise en valeur architecturale",
    tags: ["Architecture", "Reportage", "Promotion"]
  },
  {
    id: 6,
    title: "Vernissage Gloire Kasongo",
    category: "Lancement d'Album",
    image: "/images/projet5.jpeg",
    description: "Couverture audiovisuelle du lancement d'album avec captation et montage événementiel",
    tags: ["Album", "Captation", "Social Media"]
  }
];

const skills: Skill[] = [
  { name: "Captation Vidéo", level: 88, icon: <FiCamera className="w-6 h-6" /> },
  { name: "Montage Professionnel", level: 86, icon: <FiFilm className="w-6 h-6" /> },
  { name: "Réalisation Teasers", level: 90, icon: <FiVideo className="w-6 h-6" /> },
  { name: "Motion Design", level: 85, icon: <FiMonitor className="w-6 h-6" /> },
  { name: "Photographie Événementielle", level: 93, icon: <FiAperture className="w-6 h-6" /> },
  { name: "Post-Production", level: 88, icon: <FiEdit3 className="w-6 h-6" /> }
];

const services: Service[] = [
  {
    title: "Captation Vidéo",
    description: "Prises de vues cinématographiques avec équipement professionnel pour sublimer chaque moment",
    icon: <FiCamera className="w-8 h-8" />,
    features: ["Caméras 4K", "Stabilisation", "Éclairage pro", "Prise de son"]
  },
  {
    title: "Montage Cinématographique",
    description: "Montage dynamique et professionnel avec transitions fluides et colorimétrie avancée",
    icon: <FiFilm className="w-8 h-8" />,
    features: ["Adobe Premiere Pro", "After Effects", "Color Grading", "Sound Design"]
  },
  {
    title: "Teasers & Aftermovies",
    description: "Création de teasers percutants et aftermovies mémorables pour vos événements",
    icon: <FiVideo className="w-8 h-8" />,
    features: ["Montage dynamique", "Musique adaptée", "Effets visuels", "Format social"]
  },
  {
    title: "Contenu Réseaux Sociaux",
    description: "Production de contenus optimisés pour Instagram, TikTok et YouTube",
    icon: <FiMonitor className="w-8 h-8" />,
    features: ["Reels & Stories", "TikTok", "YouTube Shorts", "Carrousels"]
  },
  {
    title: "Photographie",
    description: "Photographie événementielle et paysages avec une approche artistique unique",
    icon: <FiAperture className="w-8 h-8" />,
    features: ["Événements", "Paysages", "Portrait", "Retouche Pro"]
  },
  {
    title: "Motion Design",
    description: "Animations graphiques et motion design pour dynamiser vos contenus visuels",
    icon: <FiEdit3 className="w-8 h-8" />,
    features: ["Animations 2D", "Transitions", "Logo Animation", "Infographies"]
  }
];

const stats: Stat[] = [
  { value: "50+", label: "Projets Réalisés" },
  { value: "15+", label: "Clients Satisfaits" },
  { value: "100K+", label: "Vues Générées" },
  { value: "5+", label: "Années d'Expérience" }
];

const collaborators = [
  "Shine Gospel Africa", "Christian Mukuna", "Déborah Lukalu",
  "AUA", "Expo Béton", "Batiko", "Shine Day",
  "Gloire Kasongo", "Ciné Pro", "Young in Christ"
];

const software = [
  { name: "Premiere Pro", icon: "🎬" },
  { name: "After Effects", icon: "✨" },
  { name: "Photoshop", icon: "🖼️" },
  { name: "Capcut", icon: "🏛️" },
  { name: "Lightroom", icon: "📐" }
];

// ==================== HOOKS ====================
function useMousePosition() {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handler);
    return () => window.removeEventListener('mousemove', handler);
  }, []);
  
  return position;
}

// ==================== COMPONENTS ====================

// Section Title Component
function SectionTitle({ subtitle, title, description }: { subtitle: string; title: string; description?: string }) {
  const [ref, inView] = useInView({ threshold: 0.3, triggerOnce: true });
  
  return (
    <div ref={ref} className="text-center mb-16 md:mb-20">
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6 }}
        className="text-gold text-sm font-heading font-semibold tracking-[0.3em] uppercase mb-4"
      >
        {subtitle}
      </motion.p>
      <motion.h2
        initial={{ opacity: 0, y: 30 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.7, delay: 0.1 }}
        className="text-3xl md:text-5xl lg:text-6xl font-display font-bold mb-6"
      >
        <span className="text-gradient">{title}</span>
      </motion.h2>
      {description && (
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-gray-400 text-lg max-w-2xl mx-auto font-light"
        >
          {description}
        </motion.p>
      )}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={inView ? { scaleX: 1 } : {}}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="cinematic-line max-w-[120px] mx-auto mt-8"
      />
    </div>
  );
}

// Navigation
function Navigation({ isOpen, setIsOpen }: { isOpen: boolean; setIsOpen: (v: boolean) => void }) {
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const { scrollY } = useScroll();
  
  useMotionValueEvent(scrollY, "change", (latest) => {
    setScrolled(latest > 50);
  });
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { threshold: 0.3 }
    );
    
    document.querySelectorAll('section[id]').forEach((section) => {
      observer.observe(section);
    });
    
    return () => observer.disconnect();
  }, []);
  
  const navLinks = [
    { href: '#home', label: 'Accueil' },
    { href: '#about', label: 'À Propos' },
    { href: '#skills', label: 'Compétences' },
    { href: '#services', label: 'Services' },
    { href: '#portfolio', label: 'Réalisations' },
    { href: '#gallery', label: 'Galerie' },
    { href: '#contact', label: 'Contact' }
  ];
  
  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled 
            ? 'bg-dark/90 backdrop-blur-xl border-b border-white/5 py-3' 
            : 'bg-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <motion.a
            href="#home"
            className="relative group"
            whileHover={{ scale: 1.02 }}
          >
            <span className="text-2xl font-display font-bold">
              <span className="text-white">Port</span>
              <span className="text-gradient">folio</span>
            </span>
            <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-gold transition-all duration-300 group-hover:w-full" />
          </motion.a>
          
          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className={`nav-link text-sm font-medium transition-colors duration-300 ${
                  activeSection === link.href.slice(1)
                    ? 'text-gold active'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {link.label}
              </a>
            ))}
          </div>
          
          {/* Social Links */}
          <div className="hidden lg:flex items-center gap-4">
            <a href="https://www.instagram.com/bg_capture_12?igsh=YTBjbDlmbng3ZWZ3&utm_source=qr" target="_blank" rel="noopener noreferrer" 
               className="text-gray-400 hover:text-gold transition-colors duration-300">
              <FiInstagram className="w-5 h-5" />
            </a>
            <a href="https://www.instagram.com/gradstend_picture?igsh=NW45YTllMW9ibnN4&utm_source=qr" target="_blank" rel="noopener noreferrer" 
               className="text-gray-400 hover:text-gold transition-colors duration-300">
              <FiInstagram className="w-5 h-5" />
            </a>
            <a href="#contact"
               className="ml-4 px-5 py-2.5 bg-gold/10 border border-gold/30 text-gold text-sm font-medium rounded-full hover:bg-gold hover:text-dark transition-all duration-300">
              Me Contacter
            </a>
          </div>
          
          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden text-white p-2"
          >
            {isOpen ? <FiX className="w-6 h-6" /> : <FiMenu className="w-6 h-6" />}
          </button>
        </div>
      </motion.nav>
      
      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-40 bg-dark/98 backdrop-blur-2xl lg:hidden"
          >
            <div className="flex flex-col items-center justify-center h-full gap-8">
              {navLinks.map((link, i) => (
                <motion.a
                  key={link.href}
                  href={link.href}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  onClick={() => setIsOpen(false)}
                  className="text-2xl font-display font-semibold text-white hover:text-gold transition-colors"
                >
                  {link.label}
                </motion.a>
              ))}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="flex gap-6 mt-8"
              >
                <a href="https://www.instagram.com/gradstend_picture?igsh=NW45YTllMW9ibnN4&utm_source=qr" className="text-gray-400 hover:text-gold transition-colors">
                  <FiInstagram className="w-6 h-6" />
                </a>
                
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// Hero Section
function HeroSection() {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);
  const scale = useTransform(scrollY, [0, 400], [1, 1.1]);
  
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Parallax */}
      <motion.div
        style={{ y, scale }}
        className="absolute inset-0"
      >
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: 'url(/images/intro.jpeg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-dark/60 via-dark/40 to-dark" />
        <div className="absolute inset-0 bg-gradient-to-r from-dark/80 via-transparent to-dark/80" />
      </motion.div>
      
      {/* Animated particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-gold/30 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [-20, 20],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: 3 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>
      
      {/* Content */}
      <motion.div style={{ opacity }} className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mb-6"
        >
          <span className="inline-block px-6 py-2 border border-gold/30 rounded-full text-gold text-sm font-heading tracking-[0.3em] uppercase">
            Cinéaste & Photographe Professionnel
          </span>
        </motion.div>
        
        <motion.h1
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="text-5xl md:text-7xl lg:text-8xl xl:text-9xl font-display font-bold leading-[0.9] mb-8"
        >
          <span className="block text-white">Capturer</span>
          <span className="block text-shimmer">l'Émotion</span>
          <span className="block text-white mt-2 text-3xl md:text-4xl lg:text-5xl font-light italic">
            & l'Identité Visuelle
          </span>
        </motion.h1>
        
        <motion.p
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="text-gray-300 text-lg md:text-xl max-w-3xl mx-auto mb-12 font-light leading-relaxed"
        >
          À travers chaque projet vidéo, je cherche à capturer l'émotion, l'énergie 
          et l'identité visuelle de chaque événement afin de créer des contenus 
          impactants et mémorables.
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.2 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="#portfolio"
            className="group px-8 py-4 bg-gold text-dark font-semibold rounded-full hover:bg-gold-light transition-all duration-300 flex items-center gap-2"
          >
            Voir mes réalisations
            <FiChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="#about"
            className="px-8 py-4 border border-white/20 text-white rounded-full hover:border-gold/50 hover:text-gold transition-all duration-300"
          >
            En savoir plus
          </a>
        </motion.div>
      </motion.div>
      
      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1, repeat: Infinity }}
          className="flex flex-col items-center gap-2 text-gray-400"
        >
          <span className="text-xs font-heading tracking-widest uppercase">Scroll</span>
          <FiArrowDown className="w-5 h-5" />
        </motion.div>
      </motion.div>
      
      {/* Cinematic borders */}
      <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-dark to-transparent z-10" />
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-dark to-transparent z-10" />
    </section>
  );
}

// About Section
function AboutSection() {
  const [ref, inView] = useInView({ threshold: 0.2, triggerOnce: true });
  
  return (
    <section id="about" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-gold/3 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle
          subtitle="Découvrez"
          title="À Propos de Moi"
          description="Passionné par l'art de capturer chaque moment unique à travers l'objectif"
        />
        
        <div ref={ref} className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -60 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.9, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="relative"
          >
            <div className="relative group">
              <div className="absolute -inset-4 bg-gradient-to-br from-gold/20 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative overflow-hidden rounded-2xl">
                <img
                  src="/images/about.jpeg"
                  alt="Photographe professionnel"
                  className="w-full h-[500px] object-cover parallax-img"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark/60 to-transparent" />
              </div>
              
              {/* Floating badge */}
              <motion.div
                animate={{ y: [-5, 5, -5] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="absolute -bottom-6 -right-6 md:right-8 bg-dark-card border border-gold/30 rounded-2xl p-6 shadow-2xl"
              >
                <p className="text-4xl font-display font-bold text-gradient">5+</p>
                <p className="text-gray-400 text-sm font-medium">Années d'Expérience</p>
              </motion.div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-4 -left-4 w-20 h-20 border-t-2 border-l-2 border-gold/30 rounded-tl-xl" />
            <div className="absolute -bottom-4 -right-4 w-20 h-20 border-b-2 border-r-2 border-gold/30 rounded-br-xl" />
          </motion.div>
          
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 60 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.9, delay: 0.2, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <h3 className="text-2xl md:text-3xl font-display font-semibold text-white mb-6">
              Une approche <span className="text-gradient italic">cinématographique</span> moderne
            </h3>
            
            <div className="space-y-4 text-gray-300 leading-relaxed">
              <p>
                Je réalise des captations, montages dynamiques, teasers événementiels, 
                contenus promotionnels et vidéos artistiques avec une approche cinématographique moderne.
              </p>
              <p>
                Chaque projet est une nouvelle opportunité de raconter une histoire visuelle 
                unique, en capturant l'essence et l'énergie de chaque événement avec précision 
                et créativité.
              </p>
              <p>
                Mon objectif est de transformer chaque moment en une œuvre visuelle mémorable 
                qui transcende l'ordinaire et touche véritablement le public.
              </p>
            </div>
            
            {/* Quote */}
            <div className="mt-8 pl-6 border-l-2 border-gold">
              <p className="text-gray-200 italic font-display text-lg">
                "À travers chaque projet vidéo, je cherche à capturer l'émotion, 
                l'énergie et l'identité visuelle de chaque événement."
              </p>
            </div>
            
            {/* Software */}
            <div className="mt-10">
              <h4 className="text-sm font-heading font-semibold tracking-[0.2em] uppercase text-gold mb-4">
                Logiciels Maîtrisés
              </h4>
              <div className="flex flex-wrap gap-3">
                {software.map((sw) => (
                  <div
                    key={sw.name}
                    className="px-4 py-2.5 bg-dark-card border border-dark-border rounded-xl flex items-center gap-2 hover-glow cursor-default"
                  >
                    <span className="text-lg">{sw.icon}</span>
                    <span className="text-sm text-gray-300 font-medium">{sw.name}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {/* CTA */}
            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href="#contact"
                className="group px-6 py-3 bg-gold text-dark font-semibold rounded-full hover:bg-gold-light transition-all duration-300 flex items-center gap-2"
              >
                Travaillons ensemble
                <FiChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="#services"
                className="px-6 py-3 border border-gold/30 text-gold rounded-full hover:bg-gold/10 transition-all duration-300"
              >
                Mes services
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// Stats Bar
function StatsBar() {
  const [ref, inView] = useInView({ threshold: 0.3, triggerOnce: true });
  
  return (
    <section className="relative py-16 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-dark via-dark-card to-dark" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(201,168,76,0.05)_0%,_transparent_70%)]" />
      
      <div ref={ref} className="relative max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="text-center"
            >
              <p className="text-4xl md:text-5xl font-display font-bold text-gradient stat-number mb-2">
                {stat.value}
              </p>
              <p className="text-gray-400 text-sm font-medium tracking-wider uppercase">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
      
      {/* Dividers */}
      <div className="absolute top-0 left-0 right-0 section-divider" />
      <div className="absolute bottom-0 left-0 right-0 section-divider" />
    </section>
  );
}

// Skills Section
function SkillsSection() {
  const [ref, inView] = useInView({ threshold: 0.2, triggerOnce: true });
  
  return (
    <section id="skills" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold/3 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle
          subtitle="Expertise"
          title="Mes Compétences"
          description="Un savoir-faire technique au service de votre vision créative"
        />
        
        <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skills.map((skill, i) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group relative bg-dark-card border border-dark-border rounded-2xl p-8 hover-glow overflow-hidden"
            >
              {/* Background gradient on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-gold/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold group-hover:bg-gold group-hover:text-dark transition-all duration-300">
                    {skill.icon}
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg">{skill.name}</h3>
                    <p className="text-gold text-sm font-medium">{skill.level}%</p>
                  </div>
                </div>
                
                {/* Progress bar */}
                <div className="h-1.5 bg-dark-lighter rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={inView ? { width: `${skill.level}%` } : {}}
                    transition={{ duration: 1.2, delay: 0.3 + i * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
                    className="h-full bg-gradient-to-r from-gold to-gold-light rounded-full"
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Services Section
function ServicesSection() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });
  
  return (
    <section id="services" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-gold/5 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle
          subtitle="Prestations"
          title="Mes Services"
          description="Des solutions créatives complètes pour tous vos projets visuels"
        />
        
        <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group relative bg-dark-card border border-dark-border rounded-2xl p-8 hover-glow cursor-default"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              <div className="relative">
                <div className="w-16 h-16 rounded-2xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold mb-6 group-hover:scale-110 transition-transform duration-300">
                  {service.icon}
                </div>
                
                <h3 className="text-xl font-semibold text-white mb-3 group-hover:text-gold transition-colors">
                  {service.title}
                </h3>
                
                <p className="text-gray-400 text-sm leading-relaxed mb-6">
                  {service.description}
                </p>
                
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature) => (
                    <span
                      key={feature}
                      className="text-xs px-3 py-1.5 bg-dark-lighter border border-dark-border rounded-full text-gray-400"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Portfolio Section
function PortfolioSection() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });
  
  const categories = ['all', 'Concert', 'Événement', 'Institutionnel', 'Production'];
  
  const filteredProjects = activeFilter === 'all' 
    ? projects 
    : projects.filter(p => p.category.includes(activeFilter));
  
  return (
    <section id="portfolio" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-0 left-0 w-96 h-96 bg-gold/3 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle
          subtitle="Portfolio"
          title="Mes Réalisations"
          description="Découvrez une sélection de mes projets les plus marquants"
        />
        
        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveFilter(cat)}
              className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${
                activeFilter === cat
                  ? 'bg-gold text-dark'
                  : 'bg-dark-card border border-dark-border text-gray-400 hover:border-gold/30 hover:text-white'
              }`}
            >
              {cat === 'all' ? 'Tous' : cat}
            </button>
          ))}
        </motion.div>
        
        {/* Projects Grid */}
        <div ref={ref} className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="wait">
            {filteredProjects.map((project, i) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="group relative bg-dark-card border border-dark-border rounded-2xl overflow-hidden hover-glow"
              >
                {/* Image */}
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-card via-dark-card/20 to-transparent" />
                  
                  {/* Play button overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-16 h-16 rounded-full bg-gold/90 flex items-center justify-center transform scale-50 group-hover:scale-100 transition-transform duration-300">
                      <FiPlay className="w-7 h-7 text-dark ml-1" />
                    </div>
                  </div>
                  
                  {/* Category badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1.5 bg-dark/80 backdrop-blur-sm border border-white/10 rounded-full text-xs text-gold font-medium">
                      {project.category}
                    </span>
                  </div>
                </div>
                
                {/* Content */}
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-gold transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs px-2.5 py-1 bg-dark-lighter rounded-md text-gray-500"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

// Marquee / Collaborators
function CollaboratorsSection() {
  const [ref, inView] = useInView({ threshold: 0.3, triggerOnce: true });
  
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="absolute inset-0 bg-dark-card" />
      <div className="absolute top-0 left-0 right-0 section-divider" />
      <div className="absolute bottom-0 left-0 right-0 section-divider" />
      
      <div className="relative max-w-7xl mx-auto px-6 mb-12">
        <motion.div
          ref={ref}
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <p className="text-gold text-sm font-heading font-semibold tracking-[0.3em] uppercase mb-3">
            Ils m'ont fait confiance
          </p>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-white">
            Collaborations & <span className="text-gradient">Clients</span>
          </h2>
        </motion.div>
      </div>
      
      {/* Marquee */}
      <div className="relative">
        <div className="flex overflow-hidden">
          <div className="marquee-track flex gap-8 items-center whitespace-nowrap">
            {[...collaborators, ...collaborators].map((name, i) => (
              <div
                key={`${name}-${i}`}
                className="flex items-center gap-3 px-8 py-4 bg-dark-lighter border border-dark-border rounded-xl hover-glow"
              >
                <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center text-gold text-lg font-display font-bold">
                  {name[0]}
                </div>
                <span className="text-gray-300 font-medium">{name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Gallery Section
function GallerySection() {
  const [ref, inView] = useInView({ threshold: 0.1, triggerOnce: true });
  const images = [
    { src: '/images/red.jpg', span: '' },
    { src: '/images/red1.jpg', span: '' },
    { src: '/images/bad1.jpg', span: '' },
    { src: '/images/bad2.jpg', span: '' },
    { src: '/images/red2.jpg', span: '' },
    { src: '/images/red3.jpg', span: '' },
    { src: '/images/red4.jpg', span: '' },
    { src: '/images/red5.jpg', span: '' },
    { src: '/images/red6.jpg', span: '' },
    { src: '/images/red8.jpg', span: '' },
    { src: '/images/red9.jpg', span: '' },
    
  ];
  
  return (
    <section id="gallery" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-1/2 right-0 w-80 h-80 bg-gold/3 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle
          subtitle="Visuel"
          title="Galerie"
          description="Un aperçu de mes travaux les plus récents et inspirants"
        />
        
        <div ref={ref} className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {images.map((img, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className={`group relative overflow-hidden rounded-xl ${img.span}`}
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={img.src}
                  alt={`Galerie ${i + 1}`}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-dark/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center gap-2 text-white">
                    <FiCamera className="w-5 h-5 text-gold" />
                    <span className="text-sm font-medium"></span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Testimonial / Quote Section
function QuoteSection() {
  const [ref, inView] = useInView({ threshold: 0.3, triggerOnce: true });
  
  return (
    <section className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-dark-card" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(201,168,76,0.08)_0%,_transparent_50%)]" />
      
      <div className="relative max-w-4xl mx-auto px-6 text-center">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="text-gold text-6xl font-display mb-8">"</div>
          <p className="text-2xl md:text-3xl lg:text-4xl font-display font-light text-white leading-relaxed mb-8 italic">
            À travers chaque projet vidéo, je cherche à capturer l'émotion, 
            l'énergie et l'identité visuelle de chaque événement afin de créer 
            des contenus impactants et mémorables.
          </p>
          <div className="cinematic-line max-w-[60px] mx-auto mb-6" />
          <p className="text-gold font-heading font-semibold tracking-wider uppercase text-sm">
            Cinéaste & Photographe
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// Contact Section
function ContactSection() {
  const [ref, inView] = useInView({ threshold: 0.2, triggerOnce: true });
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'sent'>('idle');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('sending');
    setTimeout(() => setFormStatus('sent'), 1000);
  };
  
  return (
    <section id="contact" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-0 left-0 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-72 h-72 bg-gold/3 rounded-full blur-3xl" />
      
      <div className="max-w-7xl mx-auto px-6">
        <SectionTitle
          subtitle="Contact"
          title="Travaillons Ensemble"
          description="Prêt à donner vie à votre prochain projet ? Discutons-en !"
        />
        
        <div ref={ref} className="grid lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: -60 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-2xl font-display font-semibold text-white mb-6">
              Parlons de votre <span className="text-gradient italic">projet</span>
            </h3>
            <p className="text-gray-400 leading-relaxed mb-10">
              Que ce soit pour un événement spécial, une production vidéo professionnelle 
              ou un projet créatif, je suis à votre écoute pour transformer votre vision 
              en réalité visuelle.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4 group">
                <div className="w-14 h-14 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold group-hover:bg-gold group-hover:text-dark transition-all duration-300">
                  <FiMail className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Email</p>
                  <p className="text-white font-medium">gradytshitende@gmail.com</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 group">
                <div className="w-14 h-14 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold group-hover:bg-gold group-hover:text-dark transition-all duration-300">
                  <FiPhone className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Téléphone</p>
                  <p className="text-white font-medium">+243 890 251 435</p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 group">
                <div className="w-14 h-14 rounded-xl bg-gold/10 border border-gold/20 flex items-center justify-center text-gold group-hover:bg-gold group-hover:text-dark transition-all duration-300">
                  <FiMapPin className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 font-medium">Localisation</p>
                  <p className="text-white font-medium">Kinshasa, RD Congo</p>
                </div>
              </div>
            </div>
            
            {/* Social Links */}
            <div className="mt-10">
              <h4 className="text-sm font-heading font-semibold tracking-[0.2em] uppercase text-gold mb-4">
                Suivez-moi
              </h4>
              <div className="flex gap-4">
                <a
                  href="https://www.instagram.com/gradstend_picture?igsh=NW45YTllMW9ibnN4&utm_source=qr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 rounded-xl bg-dark-card border border-dark-border flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/30 transition-all duration-300"
                >
                  <FiInstagram className="w-5 h-5" />
                </a>
              
             
               
              </div>
            </div>
          </motion.div>
          
          
        </div>
      </div>
    </section>
  );
}

// Footer
function Footer() {
  return (
    <footer className="relative py-16 overflow-hidden">
      <div className="absolute inset-0 bg-dark-card" />
      <div className="absolute top-0 left-0 right-0 section-divider" />
      
      <div className="relative max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <a href="#home" className="inline-block mb-4">
              <span className="text-2xl font-display font-bold">
                <span className="text-white">Port</span>
                <span className="text-gradient">folio</span>
              </span>
            </a>
            <p className="text-gray-400 text-sm leading-relaxed">
              Captation vidéo, montage cinématographique, photographie événementielle. 
              Créateur de contenus visuels impactants.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4">Navigation</h4>
            <div className="space-y-3">
              {['Accueil', 'À Propos', 'Compétences', 'Services', 'Réalisations', 'Galerie', 'Contact'].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase().replace(/ /g, '-').replace('à-propos', 'about').replace('réalisations', 'portfolio')}`}
                  className="block text-gray-400 text-sm hover:text-gold transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
          
          {/* Social */}
          <div>
            <h4 className="text-white font-semibold mb-4">Réseaux Sociaux</h4>
            <div className="flex gap-3 mb-6">
              <a href="https://www.instagram.com/gradstend_picture?igsh=NW45YTllMW9ibnN4&utm_source=qr" target="_blank" rel="noopener noreferrer"
                 className="w-10 h-10 rounded-lg bg-dark-lighter border border-dark-border flex items-center justify-center text-gray-400 hover:text-gold hover:border-gold/30 transition-all">
                <FiInstagram className="w-5 h-5" />
              </a>
            
            </div>
            <p className="text-gray-500 text-xs">
              Disponible pour des projets à Kinshasa et partout dans le monde
            </p>
          </div>
        </div>
        
        <div className="border-t border-dark-border pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-sm">
            © 2026 GRADY TSHITENDE. Tous droits réservés.
          </p>
          <p className="text-gray-600 text-xs">
            Conçu avec passion pour l'art visuel par <b><a href="https://portfolio-egide.vercel.app">4FLOWERS</a></b>
          </p>  
        </div>
      </div>
    </footer>
  );
}

// ==================== MAIN APP ====================
export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const mousePos = useMousePosition();
  
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1200);
    return () => clearTimeout(timer);
  }, []);
  
  return (
    <>  
      {/* Loading Screen */}
      <AnimatePresence>
        {loading && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="fixed inset-0 z-[100] bg-dark flex flex-col items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">
                <span className="text-white">GRADY</span>
                <span className="text-gradient">TSHITENDE</span>
              </h1>
              <p className="text-gray-500 text-sm font-heading tracking-[0.3em] uppercase mb-8">
                Portfolio Professionnel
              </p>
              <div className="w-48 loader-bar rounded-full mx-auto" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Cursor trail (desktop only) */}
      <motion.div
        className="cursor-trail hidden md:block"
        animate={{ x: mousePos.x - 10, y: mousePos.y - 10 }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      />
      
      {/* Film grain effect */}
      <div className="film-grain" />
      
      {/* Main Content */}
      <div className="relative">
        <Navigation isOpen={menuOpen} setIsOpen={setMenuOpen} />
        
        <main>
          <HeroSection />
          <AboutSection />
          <StatsBar />
          <SkillsSection />
          <ServicesSection />
          <PortfolioSection />
          <CollaboratorsSection />
          <GallerySection />
          <QuoteSection />
          <ContactSection />
        </main>
        
        <Footer />
      </div>
    </>
  );
}
